﻿namespace web_api_restaurante.Entidades
{
    public class Produto
    {
        private int id { get; set; }

        public String Nome { get; set; }

        public String Descricao { get; set; }

        public String ImageUrl { get; set; }


    }
}
